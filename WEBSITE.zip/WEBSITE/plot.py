from firebase import firebase

import numpy as np
import plotly.express as px


firebase1 = firebase.FirebaseApplication('https://hcl-hack.firebaseio.com/',None)
x = list((firebase1.get('/Right/Pitch',None)).values())
deg = x[0]


fig = px.scatter_polar(r=[80,0,0], theta=[deg,0,0],
                       range_theta=[0,360], start_angle=0, direction="counterclockwise")
fig.show()
